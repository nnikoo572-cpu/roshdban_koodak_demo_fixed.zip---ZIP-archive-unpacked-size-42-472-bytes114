import os, sqlite3, secrets
from functools import wraps
from datetime import datetime
from flask import Flask, g, render_template, request, redirect, url_for, session, flash, abort, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from io import BytesIO
import csv

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("ROSHDBAN_DB", os.path.join(APP_DIR, "roshdban.db"))
app = Flask(__name__)
app.secret_key = os.environ.get("ROSHDBAN_SECRET_KEY") or secrets.token_hex(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
if os.environ.get("ROSHDBAN_HTTPS", "0") == "1":
    app.config["SESSION_COOKIE_SECURE"] = True

DOMAINS = ["فارسی و درک مطلب", "ریاضی و حل مسئله", "علوم و مشاهده", "خلاقیت", "فضایی و فنی", "مهارت اجتماعی", "انگیزه و خودتنظیمی"]
GRADES = ["اول", "دوم", "سوم", "چهارم", "پنجم", "ششم"]
ROLES = {"admin":"مدیر سامانه","teacher":"معلم","parent":"والدین"}

def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = connect_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, display_name TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('admin','teacher','parent')),
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS students(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, grade TEXT NOT NULL,
      teacher_id INTEGER REFERENCES users(id), parent_id INTEGER REFERENCES users(id),
      status TEXT NOT NULL DEFAULT 'پیگیری عادی', created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS observations(
      id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      author_id INTEGER NOT NULL REFERENCES users(id), domain TEXT NOT NULL, evidence_type TEXT NOT NULL,
      score INTEGER NOT NULL CHECK(score BETWEEN 1 AND 4), note TEXT NOT NULL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS support_needs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      author_id INTEGER NOT NULL REFERENCES users(id), category TEXT NOT NULL, note TEXT NOT NULL,
      next_action TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'در حال پیگیری', created_at TEXT NOT NULL
    );
    """)
    if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        now = datetime.now().isoformat(timespec="minutes")
        # First-run demo accounts. Change these immediately before any real deployment.
        conn.execute("INSERT INTO users(username,password_hash,display_name,role,created_at) VALUES(?,?,?,?,?)",
                     ("admin", generate_password_hash("ChangeMe123!"), "مدیر سامانه", "admin", now))
        conn.execute("INSERT INTO users(username,password_hash,display_name,role,created_at) VALUES(?,?,?,?,?)",
                     ("teacher", generate_password_hash("Teacher123!"), "معلم نمونه", "teacher", now))
        conn.execute("INSERT INTO users(username,password_hash,display_name,role,created_at) VALUES(?,?,?,?,?)",
                     ("parent", generate_password_hash("Parent123!"), "والد نمونه", "parent", now))
        teacher_id = conn.execute("SELECT id FROM users WHERE username='teacher'").fetchone()[0]
        parent_id = conn.execute("SELECT id FROM users WHERE username='parent'").fetchone()[0]
        now_fa = now
        cur = conn.execute("INSERT INTO students(name,grade,teacher_id,parent_id,status,created_at) VALUES(?,?,?,?,?,?)",
                     ("آوا محمدی", "سوم", teacher_id, parent_id, "پیگیری عادی", now_fa))
        sid = cur.lastrowid
        conn.execute("INSERT INTO observations(student_id,author_id,domain,evidence_type,score,note,created_at) VALUES(?,?,?,?,?,?,?)",
                     (sid, teacher_id, "خلاقیت", "پروژه عملی", 4, "برای ساخت پل کاغذی دو طرح متفاوت پیشنهاد داد.", now))
        conn.execute("INSERT INTO support_needs(student_id,author_id,category,note,next_action,status,created_at) VALUES(?,?,?,?,?,?,?)",
                     (sid, teacher_id, "آموزشی", "نمونه نیاز آموزشی برای نمایش قابلیت سامانه", "بررسی مجدد در دو هفته آینده", "در حال پیگیری", now))
    conn.commit()
    conn.close()

@app.before_request
def before_request():
    g.db = connect_db()
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(24)

@app.teardown_request
def teardown_request(exc):
    db = getattr(g, "db", None)
    if db is not None:
        db.close()

@app.context_processor
def inject_globals():
    return {"current_user": current_user(), "csrf_token": session.get("csrf_token",""), "role_names": ROLES}

def current_user():
    uid = session.get("user_id")
    if not uid: return None
    try:
        return g.db.execute("SELECT id,username,display_name,role FROM users WHERE id=?", (uid,)).fetchone()
    except (AttributeError, sqlite3.OperationalError):
        return None

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not current_user():
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapped

def roles_required(*roles):
    def decorator(fn):
        @wraps(fn)
        @login_required
        def wrapped(*args, **kwargs):
            u=current_user()
            if not u or u["role"] not in roles: abort(403)
            return fn(*args, **kwargs)
        return wrapped
    return decorator

def verify_csrf():
    token=request.form.get("csrf_token","")
    if not token or not secrets.compare_digest(token, session.get("csrf_token","")):
        abort(400, "درخواست معتبر نیست؛ صفحه را دوباره بارگذاری کنید.")

def can_access_student(student_id):
    u=current_user()
    if not u: return False
    if u["role"]=="admin": return True
    col = "teacher_id" if u["role"]=="teacher" else "parent_id"
    return g.db.execute(f"SELECT 1 FROM students WHERE id=? AND {col}=?", (student_id,u["id"])).fetchone() is not None

def visible_students():
    u=current_user()
    if u["role"]=="admin":
        return g.db.execute("SELECT s.*,t.display_name AS teacher_name,p.display_name AS parent_name FROM students s LEFT JOIN users t ON s.teacher_id=t.id LEFT JOIN users p ON s.parent_id=p.id ORDER BY s.id DESC").fetchall()
    col="teacher_id" if u["role"]=="teacher" else "parent_id"
    return g.db.execute(f"SELECT s.*,t.display_name AS teacher_name,p.display_name AS parent_name FROM students s LEFT JOIN users t ON s.teacher_id=t.id LEFT JOIN users p ON s.parent_id=p.id WHERE s.{col}=? ORDER BY s.id DESC",(u["id"],)).fetchall()

@app.route("/")
def index():
    if not current_user(): return redirect(url_for("login"))
    students=visible_students()
    ids=[s["id"] for s in students]
    obs_count=0; need_count=0; recent=[]
    if ids:
        marks=",".join("?"*len(ids))
        obs_count=g.db.execute(f"SELECT COUNT(*) FROM observations WHERE student_id IN ({marks})",ids).fetchone()[0]
        need_count=g.db.execute(f"SELECT COUNT(*) FROM support_needs WHERE student_id IN ({marks}) AND status!='بسته‌شده'",ids).fetchone()[0]
        recent=g.db.execute(f"SELECT o.*,s.name AS student_name FROM observations o JOIN students s ON s.id=o.student_id WHERE o.student_id IN ({marks}) ORDER BY o.id DESC LIMIT 6",ids).fetchall()
    return render_template("dashboard.html", students=students, obs_count=obs_count, need_count=need_count, recent=recent)

@app.route("/login", methods=["GET","POST"])
def login():
    if current_user(): return redirect(url_for("index"))
    if request.method=="POST":
        verify_csrf()
        username=request.form.get("username","").strip()
        password=request.form.get("password","")
        user=g.db.execute("SELECT * FROM users WHERE username=?",(username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"]=user["id"]
            session["csrf_token"]=secrets.token_urlsafe(24)
            return redirect(url_for("index"))
        flash("نام کاربری یا رمز عبور درست نیست.", "error")
    return render_template("login.html")

@app.route("/logout", methods=["POST"])
@login_required
def logout():
    verify_csrf(); session.clear(); flash("با موفقیت خارج شدید.", "success")
    return redirect(url_for("login"))

@app.route("/students")
@login_required
def students_page():
    return render_template("students.html", students=visible_students(), grades=GRADES,
                           teachers=g.db.execute("SELECT id,display_name FROM users WHERE role='teacher' ORDER BY display_name").fetchall(),
                           parents=g.db.execute("SELECT id,display_name FROM users WHERE role='parent' ORDER BY display_name").fetchall())

@app.route("/students/add", methods=["POST"])
@roles_required("admin","teacher")
def add_student():
    verify_csrf()
    name=request.form.get("name","").strip(); grade=request.form.get("grade","")
    if not name or grade not in GRADES:
        flash("نام و پایه معتبر وارد کنید.", "error"); return redirect(url_for("students_page"))
    u=current_user()
    teacher_id = int(request.form.get("teacher_id") or u["id"]) if u["role"]=="admin" else u["id"]
    parent_raw=request.form.get("parent_id","")
    parent_id=int(parent_raw) if parent_raw.isdigit() else None
    g.db.execute("INSERT INTO students(name,grade,teacher_id,parent_id,status,created_at) VALUES(?,?,?,?,?,?)",
                 (name,grade,teacher_id,parent_id,request.form.get("status","پیگیری عادی"),datetime.now().isoformat(timespec="minutes")))
    g.db.commit(); flash("دانش‌آموز ثبت شد.", "success")
    return redirect(url_for("students_page"))

@app.route("/students/<int:sid>")
@login_required
def student_detail(sid):
    if not can_access_student(sid): abort(403)
    s=g.db.execute("SELECT s.*,t.display_name AS teacher_name,p.display_name AS parent_name FROM students s LEFT JOIN users t ON t.id=s.teacher_id LEFT JOIN users p ON p.id=s.parent_id WHERE s.id=?",(sid,)).fetchone()
    observations=g.db.execute("SELECT o.*,u.display_name AS author FROM observations o JOIN users u ON u.id=o.author_id WHERE o.student_id=? ORDER BY o.id DESC",(sid,)).fetchall()
    needs=g.db.execute("SELECT n.*,u.display_name AS author FROM support_needs n JOIN users u ON u.id=n.author_id WHERE n.student_id=? ORDER BY n.id DESC",(sid,)).fetchall()
    return render_template("student_detail.html", student=s, observations=observations, needs=needs, domains=DOMAINS)

@app.route("/students/<int:sid>/observations/add", methods=["POST"])
@roles_required("admin","teacher")
def add_observation(sid):
    verify_csrf()
    if not can_access_student(sid): abort(403)
    domain=request.form.get("domain",""); score=request.form.get("score",""); note=request.form.get("note","").strip()
    if domain not in DOMAINS or score not in {"1","2","3","4"} or not note:
        flash("اطلاعات ارزیابی کامل و معتبر نیست.", "error"); return redirect(url_for("student_detail",sid=sid))
    g.db.execute("INSERT INTO observations(student_id,author_id,domain,evidence_type,score,note,created_at) VALUES(?,?,?,?,?,?,?)",
       (sid,current_user()["id"],domain,request.form.get("evidence_type","مشاهده معلم"),int(score),note,datetime.now().isoformat(timespec="minutes")))
    g.db.commit(); flash("مشاهده ثبت شد.", "success")
    return redirect(url_for("student_detail",sid=sid))

@app.route("/students/<int:sid>/needs/add", methods=["POST"])
@roles_required("admin","teacher")
def add_need(sid):
    verify_csrf()
    if not can_access_student(sid): abort(403)
    category=request.form.get("category",""); note=request.form.get("note","").strip(); action=request.form.get("next_action","").strip()
    if not category or not note or not action:
        flash("دسته، توضیح و اقدام بعدی را وارد کنید.", "error"); return redirect(url_for("student_detail",sid=sid))
    g.db.execute("INSERT INTO support_needs(student_id,author_id,category,note,next_action,status,created_at) VALUES(?,?,?,?,?,?,?)",
       (sid,current_user()["id"],category,note,action,"در حال پیگیری",datetime.now().isoformat(timespec="minutes")))
    g.db.commit(); flash("مورد حمایتی ثبت شد.", "success")
    return redirect(url_for("student_detail",sid=sid))

@app.route("/needs/<int:nid>/toggle", methods=["POST"])
@roles_required("admin","teacher")
def toggle_need(nid):
    verify_csrf()
    n=g.db.execute("SELECT * FROM support_needs WHERE id=?",(nid,)).fetchone()
    if not n: abort(404)
    if not can_access_student(n["student_id"]): abort(403)
    status="بسته‌شده" if n["status"]!="بسته‌شده" else "در حال پیگیری"
    g.db.execute("UPDATE support_needs SET status=? WHERE id=?",(status,nid)); g.db.commit()
    return redirect(url_for("student_detail",sid=n["student_id"]))

@app.route("/reports")
@login_required
def reports():
    return render_template("reports.html", students=visible_students())

@app.route("/reports/<int:sid>.csv")
@login_required
def export_csv(sid):
    if not can_access_student(sid): abort(403)
    s=g.db.execute("SELECT * FROM students WHERE id=?",(sid,)).fetchone()
    rows=g.db.execute("SELECT created_at,domain,evidence_type,score,note FROM observations WHERE student_id=? ORDER BY id",(sid,)).fetchall()
    out=BytesIO()
    # UTF-8 BOM for spreadsheet compatibility
    out.write(b'\xef\xbb\xbf')
    import io
    wrapper=io.TextIOWrapper(out,encoding="utf-8",newline="",write_through=True)
    writer=csv.writer(wrapper)
    writer.writerow(["دانش‌آموز","پایه","تاریخ","حوزه","نوع شواهد","سطح ۱ تا ۴","توضیح"])
    for r in rows: writer.writerow([s["name"],s["grade"],r["created_at"],r["domain"],r["evidence_type"],r["score"],r["note"]])
    wrapper.flush(); out.seek(0)
    return send_file(out,mimetype="text/csv; charset=utf-8",as_attachment=True,download_name=f"roshdban-student-{sid}.csv")

@app.route("/users", methods=["GET","POST"])
@roles_required("admin")
def users_page():
    if request.method=="POST":
        verify_csrf()
        username=request.form.get("username","").strip()
        display=request.form.get("display_name","").strip()
        password=request.form.get("password","")
        role=request.form.get("role","")
        if len(username)<3 or len(password)<12 or not display or role not in ROLES:
            flash("نام کاربری حداقل ۳ نویسه، رمز حداقل ۱۲ نویسه و نقش معتبر لازم است.", "error")
        else:
            try:
                g.db.execute("INSERT INTO users(username,password_hash,display_name,role,created_at) VALUES(?,?,?,?,?)",
                             (username,generate_password_hash(password),display,role,datetime.now().isoformat(timespec="minutes")))
                g.db.commit(); flash("کاربر ایجاد شد.", "success")
            except sqlite3.IntegrityError:
                flash("این نام کاربری قبلاً ثبت شده است.", "error")
        return redirect(url_for("users_page"))
    users=g.db.execute("SELECT id,username,display_name,role,created_at FROM users ORDER BY id").fetchall()
    return render_template("users.html", users=users)

@app.errorhandler(403)
def forbidden(e): return render_template("error.html", code="۴۰۳", message="شما به این بخش یا پرونده دسترسی ندارید."),403
@app.errorhandler(404)
def not_found(e): return render_template("error.html", code="۴۰۴", message="صفحه یا پرونده موردنظر پیدا نشد."),404
@app.errorhandler(400)
def bad_request(e): return render_template("error.html", code="۴۰۰", message="درخواست معتبر نیست. صفحه را تازه‌سازی کنید."),400

init_db()

if __name__ == "__main__":
    # Local development only. For production, use a WSGI server and HTTPS reverse proxy.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT","5000")), debug=False)
